/*
 *  main.h
 *  Tanks
 *
 *  Created by Chris Cooper on 09-11-04.
 *  Copyright 2009 Doliaris Software Consulting Ltd.. All rights reserved.
 *
 */

#include "Definitions.h"
#include "Cutils.h"
#include "Bullet.h"
#include "Tank.h"

#ifndef _MAIN.H
#define _MAIN.H

void handleKeypress(unsigned char key, int x, int y);
void handleSpecialKeypress(int key, int x, int y);
void handleResize(int w, int h);
void handlePassiveMouse(int x, int y);
void handleActiveMouse(int x, int y);


void initRendering();
void drawScene();
void update(int value);
int main(int argc, char** argv);
void makeTank();
void handleKeyUp(unsigned char key, int x, int y);
void checkInput();
void playerFire(int button, int state, int x, int y);
void createTank(float x, float y);

#endif

//TO DO

//Bullet velocity inheritance/Do bullet velocity properly
//i.e.currently the bullet firing speed is independent of tank speed and direction

//Radar vision
//Let's you briefly see the whole battlefield without fog

//COMMENTS
//Because everyone loves to comment...

//Zoom along gun
//When you hold down a certain key, i want the camera to zoom down to be looking along the turret's gun

//Health/Shield(?ammo?) bars
//It's annoying to not know your own health and shield levels, and I might add an ammo limit to discourage gun-spamming

//Obstacles
//Add some interest/strategy to the map

//Collisions
//So you can't run into other tanks/off the map (or into obstacles, if I've added those by this point)

//Formal game components
//Such as levels with different numbers/skills of tanks, and maybe a screen that appears to tell you when you've died or won


//Make tanks not start right next to you
//Because it's nice to have some time to orient yourself







