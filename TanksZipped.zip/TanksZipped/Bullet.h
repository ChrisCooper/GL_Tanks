/*
 *  Bullet.h
 *  Tanks
 *
 *  Created by Chris Cooper on 09-11-04.
 *  Copyright 2009 Doliaris Software Consulting Ltd.. All rights reserved.
 *
 */

#include "Definitions.h"

#ifndef _BULLET.H
#define _BULLET.H

class Bullet {
public:
	Bullet(float positionX, float positionY, float positionZ, float initialRotation);
	void drawSelf();
	void move();
	void flagAsDead();
	bool isDead();
	float givePosX();
	float givePosZ();
	
private:
	float speed;
	float posX, posY, posZ;
	float rotation;
	int remainingLife;
};

#endif