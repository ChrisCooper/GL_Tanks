/*
 *  Globals.h
 *  Tanks
 *
 *  Created by Chris Cooper on 09-11-04.
 *  Copyright 2009 Doliaris Software Consulting Ltd.. All rights reserved.
 *
 */

#include "Definitions.h"
#include "Bullet.h"
#include "Tank.h"

extern bool keyDown[256];
extern bool leftMouseDown;

extern bool isFullscreen;
extern float bulletSpeed;
extern int playerHealth;

extern float screenShakeMagnitude;
extern float zoomMagnitude;
extern int screenWidth, screenHeight;

extern int lastMouseX;
extern float lagDistance;

extern Bullet* aBullet;
extern Tank* playerTank;

extern std::vector<Bullet*> bullets;
extern std::vector<Tank*> tanks;

extern float fogColour[];
