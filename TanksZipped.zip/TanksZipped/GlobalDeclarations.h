/*
 *  GlobalDeclarations.h
 *  Tanks
 *
 *  Created by Chris Cooper on 09-11-04.
 *  Copyright 2009 Doliaris Software Consulting Ltd.. All rights reserved.
 *
 */

bool keyDown[256];
bool leftMouseDown = false;

bool isFullscreen = true;
float bulletSpeed = 0.3f;
int playerHealth = 10;
float screenShakeMagnitude= 0.0f;
float zoomMagnitude = 0.0f;
int screenWidth = 0, screenHeight = 0;

int lastMouseX = 770;
float lagDistance = 0;

Bullet* aBullet;
Tank* playerTank;

std::vector<Bullet*> bullets;
std::vector<Tank*> tanks;

float fogColour[] = {0.2f,0.58f,0.79f,0.0f};
