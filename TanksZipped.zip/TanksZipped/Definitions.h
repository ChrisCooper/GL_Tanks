/*
 *  Definitions.h
 *  Tanks
 *
 *  Created by Chris Cooper on 09-11-04.
 *  Copyright 2009 Doliaris Software Consulting Ltd.. All rights reserved.
 *
 */

#ifndef _DEFINITIONS.H 
#define _DEFINITIONS.H


	#define PI 3.141592654
	#include <iostream>
	#include <stdlib.h>
	#include <math.h>
	#include <vector>

	#ifdef __APPLE__
		#include <OpenGL/OpenGL.h>
		#include <GLUT/glut.h>
	#else
		#include <GL/glut.h>
	#endif

#endif
