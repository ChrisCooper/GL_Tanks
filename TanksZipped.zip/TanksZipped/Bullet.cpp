/*
 *  Bullet.cpp
 *  Tanks
 *
 *  Created by Chris Cooper on 09-11-04.
 *  Copyright 2009 Doliaris Software Consulting Ltd.. All rights reserved.
 *
 */

#include "Bullet.h"
#include "Cutils.h"
#include "Globals.h"

Bullet::Bullet(float positionX, float positionY, float positionZ, float initialRotation){
	this->speed = bulletSpeed;
	this->posX = positionX;
	this->posY = positionY;
	this->posZ = positionZ;
	this->rotation = initialRotation + 180;
	this->remainingLife = 300;
}

void Bullet::drawSelf(){
	glPushMatrix();
	glTranslatef(this->posX, this->posY, this->posZ);
	glRotatef(this->rotation, 0.0f, 1.0f, 0.0f);
	glColor3f(0.0f, 0.0f, 0.0f);
	makeRectangularPrism(0.03f, -0.03f, -0.03f, -0.03f, 0.03f, 0.03f);
	glPopMatrix();
}

void Bullet::move(){
	this->posX += this->speed * sin(PI/180*(this->rotation));
	this->posZ += this->speed * cos(PI/180*(this->rotation));
	this->remainingLife -= 1;
}

void Bullet::flagAsDead(){
	this->remainingLife = 0;
}

bool Bullet::isDead(){
	return this->remainingLife <= 0;
}

float Bullet::givePosX(){
	return this->posX;
}
float Bullet::givePosZ(){
	return this->posZ;
}